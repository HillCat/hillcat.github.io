---
layout: post
title: 英文口语输出训练/影子跟读硬件设备(7)
categories: English
description: 英文自学
keywords: English
---

影子跟读，这里推荐用台式机windows。

第一个设备是Bose QC35 二代 蓝牙降噪耳机；
第二个设备是Blue Yeti麦克风 ，带监听功能；

参考Matt这个视频推荐：

[Matt vs Japan's Ideal Shadowing Setup - How to Shadow](https://youtu.be/8qx_hnAGc-k)

<img src="https://cs-cn.top/images/posts/English_Shadowing74430.jpg"/>



BOSE QC 35的降噪的效果还是有点超出我的意外，听力这块必备工具。

录音软件使用[Audacity](https://www.fosshub.com/Audacity-old.html)，这是一个开源软件使用人数还是蛮多的。

### Blue Yeti的使用感受

Blue Yeti应该是训练口语输出比较理想的设备。在影子跟读中，可以给影子跟读进行录音。

这套装备具体使用起来是个什么感受呢，我用这个麦克风录制了一段17分钟的评测视频：

链接：[https://pan.baidu.com/s/1OVJ11ZYp8GxkVMmEashQjg](https://pan.baidu.com/s/1OVJ11ZYp8GxkVMmEashQjg ) 
提取码：668c





