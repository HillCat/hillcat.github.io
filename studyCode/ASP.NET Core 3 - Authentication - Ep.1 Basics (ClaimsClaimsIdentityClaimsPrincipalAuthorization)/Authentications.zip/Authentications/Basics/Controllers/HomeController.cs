﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Basics.Controllers
{
    public class HomeController:Controller
    {
        public IActionResult Index()
        {
            return View();

        }
        [Authorize]
        public IActionResult Secret()
        {
            return View();
        }

        public IActionResult Authenticate()
        {
            //生产环境是需要获取到当前用户Claim数据（这里为了演示是手动构造Claim）
            var grandmaCliams = new List<Claim>()
            {
                new Claim(ClaimTypes.Name, "Bob"),
                new Claim(ClaimTypes.Email, "Bob@fmail.com"),
                new Claim("Grandma.Says", "Very nice boi."),
            };

            var licenseClaims = new List<Claim>()
            {
                new Claim(ClaimTypes.Name, "Bob K Foo"),
                new Claim("DrivingLicense", "A+"),
            };
            //这里只是模拟浏览器端产生cookie，模拟整个权限验证过程，和实际的生产代码还是有很大的差距
            var grandmaIdentity = new ClaimsIdentity(grandmaCliams, "Grandma Identity");
            var licenseIdentity = new ClaimsIdentity(licenseClaims, "Government");

            var userPrincipal = new ClaimsPrincipal(new[] { grandmaIdentity, licenseIdentity });
            //微软框架，从数据库拿到用户claims数据之后，创建Identity对象，并把它传送到SignInAsync函数中

            HttpContext.SignInAsync(userPrincipal);//这个函数是微软框架在底层调用的，这个是在验证了用户名和密码正确之后，开始登陆操作，并且产生kookie发送给前端。
            //首先访问index的时候会执行这里的代码，给前端发送cookie，等到前端保存了cookie之后，再次访问/home/secret页面就可以通过。

            return RedirectToAction("Index");
        }
    }
}
